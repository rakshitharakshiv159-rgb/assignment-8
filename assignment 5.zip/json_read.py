import json
with open("students.json","r") as f:
    data = json.load(f)
print(data)