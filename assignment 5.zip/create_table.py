import mysql.connector
conn = mysql.connector.connect(host="localhost", user="root", password="your_password", database="testdb")
cursor = conn.cursor()
cursor.execute("CREATE TABLE IF NOT EXISTS employees (id INT, name VARCHAR(50), salary INT, department VARCHAR(50))")
print("Table created")