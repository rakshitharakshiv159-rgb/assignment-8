import json
students = [{"name":"A","age":20},{"name":"B","age":21},{"name":"C","age":22}]
with open("students.json","w") as f:
    json.dump(students,f)