s = input("Enter string: ")
count = 0
for i in s.lower():
    if i in 'aeiou':
        count += 1
print(count)