import mysql.connector
conn = mysql.connector.connect(host="localhost", user="root", password="your_password", database="testdb")
cursor = conn.cursor()
cursor.execute("SELECT * FROM employees WHERE salary > 50000")
print(cursor.fetchall())