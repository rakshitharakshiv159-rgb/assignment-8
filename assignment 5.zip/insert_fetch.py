import mysql.connector
conn = mysql.connector.connect(host="localhost", user="root", password="your_password", database="testdb")
cursor = conn.cursor()
data = [(1,'A',60000,'IT'),(2,'B',40000,'HR'),(3,'C',70000,'IT'),(4,'D',30000,'Sales'),(5,'E',80000,'IT')]
cursor.executemany("INSERT INTO employees VALUES (%s,%s,%s,%s)", data)
conn.commit()
cursor.execute("SELECT * FROM employees")
for row in cursor.fetchall():
    print(row)