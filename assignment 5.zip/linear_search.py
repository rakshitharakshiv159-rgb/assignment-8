arr = [1,2,3,4]
key = 3
for i in range(len(arr)):
    if arr[i] == key:
        print("Found at", i)