import mysql.connector
conn = mysql.connector.connect(host="localhost", user="root", password="your_password", database="testdb")
cursor = conn.cursor()
cursor.execute("UPDATE employees SET salary=90000 WHERE id=1")
cursor.execute("DELETE FROM employees WHERE id=2")
conn.commit()
print("Updated and Deleted")